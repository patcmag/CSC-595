function getAvgMiles(comm_area_number) {
	//somehow this would have access to the rideshare data (import in this file?)
	//the .on(mouseover) event would call this and it would search through to 
	//compute average mileage for a given community area number
}
function MapVis() {

	var newMV = {

		drawMapVis: function (svg, mapdata) {

			var projection = d3.geoMercator()
				.scale(50000)
				.translate([76860, 40500]);

			var path = d3.geoPath().projection(projection);

			d3.json(mapdata, function (err, topology) {

				svg.selectAll("comm_areas")
                    .data(topojson.feature(topology, topology.objects.city).features)
                    .enter()
                    .append("path")
                    .attr("d", path)
                    .attr("fill", "lightblue")
                    .attr("stroke", "black")
                    .attr("stroke-width", "0.5px")

					.on("mouseover", function (d) {
						var comm_id = d.properties.area_num_1;
						//"area_num_1" is the property in the json that corresponds to 
						//community area number. 	


                        var comm_name = d.properties.community;
                        // console.log(comm_name);
                        d3.select(this).style("fill", "yellow");
						return document.getElementById('community_name').innerHTML=comm_name;
			
					})
					.on("mouseout", function () {
                        d3.select(this).style("fill", "lightblue");
                        return document.getElementById('community_name').innerHTML = null;
					});

			})
		}
	};
	return newMV;
}